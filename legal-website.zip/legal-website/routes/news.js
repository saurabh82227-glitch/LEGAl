const express = require('express');
const router = express.Router();
const db = require('../db/init.js');

// GET /api/news -> list, optional ?category=, ?search=
router.get('/', (req, res) => {
  const { category, search } = req.query;
  let query = 'SELECT * FROM news WHERE 1=1';
  const params = [];

  if (category) {
    query += ' AND category = ?';
    params.push(category);
  }
  if (search) {
    query += ' AND (title LIKE ? OR content LIKE ?)';
    const s = `%${search}%`;
    params.push(s, s);
  }
  query += ' ORDER BY published_date DESC, id DESC';

  const rows = db.prepare(query).all(...params);
  res.json(rows);
});

router.get('/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM news WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'News item not found' });
  res.json(row);
});

// POST /api/news -> add news item (admin use)
router.post('/', (req, res) => {
  const { title, content, category, source_name, source_url, published_date } = req.body;
  if (!title || !content || !published_date) {
    return res.status(400).json({ error: 'title, content, and published_date are required' });
  }
  const info = db.prepare(
    'INSERT INTO news (title, content, category, source_name, source_url, published_date) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(title, content, category || 'General', source_name || '', source_url || '', published_date);
  res.status(201).json({ id: info.lastInsertRowid });
});

router.put('/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM news WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'News item not found' });
  const { title, content, category, source_name, source_url, published_date } = req.body;
  db.prepare(
    'UPDATE news SET title=?, content=?, category=?, source_name=?, source_url=?, published_date=? WHERE id=?'
  ).run(
    title || existing.title,
    content || existing.content,
    category || existing.category,
    source_name !== undefined ? source_name : existing.source_name,
    source_url !== undefined ? source_url : existing.source_url,
    published_date || existing.published_date,
    req.params.id
  );
  res.json({ success: true });
});

router.delete('/:id', (req, res) => {
  const info = db.prepare('DELETE FROM news WHERE id = ?').run(req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: 'News item not found' });
  res.json({ success: true });
});

module.exports = router;
