const express = require('express');
const router = express.Router();
const db = require('../db/init.js');

router.get('/', (req, res) => {
  const { category, search } = req.query;
  let query = 'SELECT * FROM faqs WHERE 1=1';
  const params = [];

  if (category) {
    query += ' AND category = ?';
    params.push(category);
  }
  if (search) {
    query += ' AND (question LIKE ? OR answer LIKE ?)';
    const s = `%${search}%`;
    params.push(s, s);
  }
  query += ' ORDER BY id ASC';

  const rows = db.prepare(query).all(...params);
  res.json(rows);
});

router.get('/categories', (req, res) => {
  const rows = db.prepare('SELECT DISTINCT category FROM faqs ORDER BY category ASC').all();
  res.json(rows.map(r => r.category));
});

router.post('/', (req, res) => {
  const { question, answer, category } = req.body;
  if (!question || !answer) {
    return res.status(400).json({ error: 'question and answer are required' });
  }
  const info = db.prepare(
    'INSERT INTO faqs (question, answer, category) VALUES (?, ?, ?)'
  ).run(question, answer, category || 'General');
  res.status(201).json({ id: info.lastInsertRowid });
});

router.put('/:id', (req, res) => {
  const existing = db.prepare('SELECT * FROM faqs WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'FAQ not found' });
  const { question, answer, category } = req.body;
  db.prepare('UPDATE faqs SET question=?, answer=?, category=? WHERE id=?').run(
    question || existing.question,
    answer || existing.answer,
    category || existing.category,
    req.params.id
  );
  res.json({ success: true });
});

router.delete('/:id', (req, res) => {
  const info = db.prepare('DELETE FROM faqs WHERE id = ?').run(req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: 'FAQ not found' });
  res.json({ success: true });
});

module.exports = router;
