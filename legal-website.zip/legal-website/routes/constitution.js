const express = require('express');
const router = express.Router();
const db = require('../db/init.js');

// GET /api/constitution -> list all, optional ?part=, ?search=
router.get('/', (req, res) => {
  const { part, search } = req.query;
  let query = 'SELECT * FROM constitution_articles WHERE 1=1';
  const params = [];

  if (part) {
    query += ' AND part = ?';
    params.push(part);
  }
  if (search) {
    query += ' AND (title LIKE ? OR summary LIKE ? OR article_number LIKE ? OR tags LIKE ?)';
    const s = `%${search}%`;
    params.push(s, s, s, s);
  }
  query += ' ORDER BY id ASC';

  const rows = db.prepare(query).all(...params);
  res.json(rows);
});

// GET /api/constitution/parts -> distinct list of parts
router.get('/parts', (req, res) => {
  const rows = db.prepare('SELECT DISTINCT part FROM constitution_articles ORDER BY id ASC').all();
  res.json(rows.map(r => r.part));
});

// GET /api/constitution/:id
router.get('/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM constitution_articles WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Article not found' });
  res.json(row);
});

// POST /api/constitution -> add new article (admin use)
router.post('/', (req, res) => {
  const { part, article_number, title, summary, tags } = req.body;
  if (!part || !article_number || !title || !summary) {
    return res.status(400).json({ error: 'part, article_number, title, and summary are required' });
  }
  try {
    const info = db.prepare(
      'INSERT INTO constitution_articles (part, article_number, title, summary, tags) VALUES (?, ?, ?, ?, ?)'
    ).run(part, article_number, title, summary, tags || '');
    res.status(201).json({ id: info.lastInsertRowid });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// PUT /api/constitution/:id -> update article
router.put('/:id', (req, res) => {
  const { part, article_number, title, summary, tags } = req.body;
  const existing = db.prepare('SELECT * FROM constitution_articles WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Article not found' });

  db.prepare(
    'UPDATE constitution_articles SET part=?, article_number=?, title=?, summary=?, tags=? WHERE id=?'
  ).run(
    part || existing.part,
    article_number || existing.article_number,
    title || existing.title,
    summary || existing.summary,
    tags !== undefined ? tags : existing.tags,
    req.params.id
  );
  res.json({ success: true });
});

// DELETE /api/constitution/:id
router.delete('/:id', (req, res) => {
  const info = db.prepare('DELETE FROM constitution_articles WHERE id = ?').run(req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: 'Article not found' });
  res.json({ success: true });
});

module.exports = router;
