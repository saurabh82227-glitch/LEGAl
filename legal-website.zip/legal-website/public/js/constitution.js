const resultsEl = document.getElementById('results');
const searchInput = document.getElementById('searchInput');
const partFilter = document.getElementById('partFilter');

let debounceTimer;

async function loadParts() {
  try {
    const res = await fetch('/api/constitution/parts');
    const parts = await res.json();
    parts.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p;
      opt.textContent = p;
      partFilter.appendChild(opt);
    });
  } catch (e) {
    console.error('Failed to load parts', e);
  }
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

async function loadArticles() {
  const search = searchInput.value.trim();
  const part = partFilter.value;
  const params = new URLSearchParams();
  if (search) params.set('search', search);
  if (part) params.set('part', part);

  resultsEl.innerHTML = '<div class="empty-state">Loading articles…</div>';

  try {
    const res = await fetch('/api/constitution?' + params.toString());
    const articles = await res.json();

    if (articles.length === 0) {
      resultsEl.innerHTML = '<div class="empty-state">No articles match your search. Try a different keyword.</div>';
      return;
    }

    resultsEl.innerHTML = articles.map(a => `
      <div class="entry">
        <span class="entry-tag">${escapeHtml(a.part)}</span>
        <h3><span class="article-number">${escapeHtml(a.article_number)}</span> — ${escapeHtml(a.title)}</h3>
        <p>${escapeHtml(a.summary)}</p>
      </div>
    `).join('');
  } catch (e) {
    resultsEl.innerHTML = '<div class="empty-state">Could not load articles. Please check the server is running.</div>';
    console.error(e);
  }
}

searchInput.addEventListener('input', () => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(loadArticles, 250);
});
partFilter.addEventListener('change', loadArticles);

loadParts();
loadArticles();
