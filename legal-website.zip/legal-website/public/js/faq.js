const resultsEl = document.getElementById('results');
const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
let debounceTimer;

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

async function loadCategories() {
  try {
    const res = await fetch('/api/faq/categories');
    const cats = await res.json();
    cats.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c;
      opt.textContent = c;
      categoryFilter.appendChild(opt);
    });
  } catch (e) { console.error(e); }
}

async function loadFaqs() {
  const search = searchInput.value.trim();
  const category = categoryFilter.value;
  const params = new URLSearchParams();
  if (search) params.set('search', search);
  if (category) params.set('category', category);

  resultsEl.innerHTML = '<div class="empty-state">Loading questions…</div>';

  try {
    const res = await fetch('/api/faq?' + params.toString());
    const items = await res.json();

    if (items.length === 0) {
      resultsEl.innerHTML = '<div class="empty-state">No questions match your search.</div>';
      return;
    }

    resultsEl.innerHTML = items.map(f => `
      <div class="faq-item">
        <button class="faq-q" data-id="${f.id}">
          <span>${escapeHtml(f.question)}</span>
          <span class="cat">${escapeHtml(f.category)} <span class="chevron">&#10148;</span></span>
        </button>
        <div class="faq-a">${escapeHtml(f.answer)}</div>
      </div>
    `).join('');

    document.querySelectorAll('.faq-q').forEach(btn => {
      btn.addEventListener('click', () => {
        btn.closest('.faq-item').classList.toggle('open');
      });
    });
  } catch (e) {
    resultsEl.innerHTML = '<div class="empty-state">Could not load questions. Please check the server is running.</div>';
    console.error(e);
  }
}

searchInput.addEventListener('input', () => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(loadFaqs, 250);
});
categoryFilter.addEventListener('change', loadFaqs);

loadCategories();
loadFaqs();
