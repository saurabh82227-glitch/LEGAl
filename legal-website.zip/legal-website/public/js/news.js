const resultsEl = document.getElementById('results');
const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
let debounceTimer;

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function formatDate(d) {
  try {
    return new Date(d).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' });
  } catch { return d; }
}

async function loadNews() {
  const search = searchInput.value.trim();
  const category = categoryFilter.value;
  const params = new URLSearchParams();
  if (search) params.set('search', search);
  if (category) params.set('category', category);

  resultsEl.innerHTML = '<div class="empty-state">Loading news…</div>';

  try {
    const res = await fetch('/api/news?' + params.toString());
    const items = await res.json();

    if (items.length === 0) {
      resultsEl.innerHTML = '<div class="empty-state">No news items match your search.</div>';
      return;
    }

    const categories = new Set(items.map(i => i.category));
    if (categoryFilter.children.length <= 1) {
      items.forEach(i => {
        if (![...categoryFilter.options].some(o => o.value === i.category)) {
          const opt = document.createElement('option');
          opt.value = i.category;
          opt.textContent = i.category;
          categoryFilter.appendChild(opt);
        }
      });
    }

    resultsEl.innerHTML = items.map(n => `
      <div class="entry">
        <span class="entry-tag">${escapeHtml(n.category)}</span>
        <h3>${escapeHtml(n.title)}</h3>
        <p>${escapeHtml(n.content)}</p>
        <div class="meta">
          ${formatDate(n.published_date)}${n.source_name ? ' &middot; ' + escapeHtml(n.source_name) : ''}
          ${n.source_url ? ` &middot; <a href="${escapeHtml(n.source_url)}" target="_blank" rel="noopener">Source</a>` : ''}
        </div>
      </div>
    `).join('');
  } catch (e) {
    resultsEl.innerHTML = '<div class="empty-state">Could not load news. Please check the server is running.</div>';
    console.error(e);
  }
}

searchInput.addEventListener('input', () => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(loadNews, 250);
});
categoryFilter.addEventListener('change', loadNews);

loadNews();
