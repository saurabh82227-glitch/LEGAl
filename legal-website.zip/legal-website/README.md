# Nyaya Portal — Indian Legal News, Q&A & Constitution Database

A full-stack website with three sections:
1. **Constitution Database** — searchable, plain-language summaries of Indian Constitution articles (Preamble, Fundamental Rights, Directive Principles, Fundamental Duties).
2. **Legal News** — a feed you manage (add/edit/delete items via the API).
3. **Legal Q&A / FAQ** — pre-written questions and answers you manage, organized by category.

## Tech stack
- **Backend:** Node.js + Express
- **Database:** SQLite (via `better-sqlite3`) — a single file, no separate database server needed
- **Frontend:** Plain HTML/CSS/JS (no build step, no framework)

## Running it locally

1. Install [Node.js](https://nodejs.org) (v18 or later).
2. In this folder, install dependencies:
   ```
   npm install
   ```
3. Start the server:
   ```
   npm start
   ```
4. Open **http://localhost:3000** in your browser.

The database file is created automatically at `db/legal_portal.db` on first run, seeded with:
- 41 Constitution articles (Preamble, Arts. 12–32, 36–51, 51A)
- 1 sample news item
- 10 sample FAQs

## Project structure
```
legal-website/
├── server.js              # Express app entry point
├── db/
│   └── init.js             # schema + seed data (runs automatically)
├── routes/
│   ├── constitution.js     # /api/constitution
│   ├── news.js              # /api/news
│   └── faq.js                # /api/faq
└── public/                 # frontend (served as static files)
    ├── index.html
    ├── constitution.html
    ├── news.html
    ├── faq.html
    ├── css/style.css
    └── js/*.js
```

## Managing content

There's no admin UI yet — you manage content via the API (e.g. with `curl`, Postman, or a quick script). All three resources support the same pattern:

**Add a news item:**
```bash
curl -X POST http://localhost:3000/api/news \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Supreme Court ruling on X",
    "content": "Plain-language summary of the ruling...",
    "category": "Judiciary",
    "source_name": "The Hindu",
    "source_url": "https://example.com/article",
    "published_date": "2026-09-25"
  }'
```

**Add an FAQ:**
```bash
curl -X POST http://localhost:3000/api/faq \
  -H "Content-Type: application/json" \
  -d '{
    "question": "What is bail?",
    "answer": "Bail is the temporary release of an accused person...",
    "category": "Criminal Law"
  }'
```

**Add a Constitution article:**
```bash
curl -X POST http://localhost:3000/api/constitution \
  -H "Content-Type: application/json" \
  -d '{
    "part": "Part III",
    "article_number": "Art. 31",
    "title": "Right to Property (Repealed)",
    "summary": "...",
    "tags": "property"
  }'
```

`PUT /api/{resource}/:id` updates an entry, `DELETE /api/{resource}/:id` removes one, and `GET /api/{resource}?search=...` searches. See the route files in `routes/` for full details.

### Completing the Constitution database
Only the most-referenced parts are seeded (Fundamental Rights, Directive Principles, Fundamental Duties, Preamble). To add the rest (e.g. Union/State government structure, Emergency provisions, Schedules), use the same `POST /api/constitution` pattern, or add rows directly to the `articles` array in `db/init.js` before first run.

## Important legal note
This portal is meant as a **civic reference and FAQ tool**, not a source of legal advice. Keep (or adapt) the disclaimer in the footer of every page: users with real legal problems should consult a qualified advocate.

## Deploying it for real users

Since this is a standard Node.js + SQLite app, it deploys to almost any host. A few good options:

- **Railway / Render**: connect your GitHub repo, set the start command to `npm start`, and it will build and deploy automatically. Note: SQLite's file needs a **persistent disk/volume** (both platforms offer one) — without it, your data resets on every redeploy.
- **A VPS (e.g. DigitalOcean, Linode)**: `git clone` your repo, `npm install`, run with a process manager like [pm2](https://pm2.keymetrics.io/) (`pm2 start server.js`), and put Nginx in front for a domain + HTTPS.
- **Fly.io**: supports persistent volumes for the SQLite file and has a generous free tier.

If you expect heavy concurrent traffic later, SQLite can be swapped for PostgreSQL — the route files use plain SQL, so the migration is mostly changing the `db/init.js` connection logic and query syntax.

### Before going live, consider adding:
- **Authentication** on the `POST`/`PUT`/`DELETE` routes (right now anyone with the URL can edit content) — e.g. a simple API key check or a login-protected admin page.
- **Rate limiting** (e.g. the `express-rate-limit` package) to prevent abuse.
- **HTTPS**, via your host or a reverse proxy like Nginx/Caddy.
- **A sitemap / basic SEO tags** if you want the Constitution database to be found via search engines.
