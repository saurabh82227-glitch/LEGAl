const express = require('express');
const cors = require('cors');
const path = require('path');

// Initializing db/init.js also creates & seeds the database on first run
require('./db/init.js');

const constitutionRoutes = require('./routes/constitution.js');
const newsRoutes = require('./routes/news.js');
const faqRoutes = require('./routes/faq.js');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api/constitution', constitutionRoutes);
app.use('/api/news', newsRoutes);
app.use('/api/faq', faqRoutes);

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

app.listen(PORT, () => {
  console.log(`Legal portal running at http://localhost:${PORT}`);
});
