const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'legal_portal.db'));

db.exec(`
CREATE TABLE IF NOT EXISTS constitution_articles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  part TEXT NOT NULL,
  article_number TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  summary TEXT NOT NULL,
  tags TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS news (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  category TEXT DEFAULT 'General',
  source_name TEXT,
  source_url TEXT,
  published_date TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS faqs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  category TEXT DEFAULT 'General'
);
`);

const articleCount = db.prepare('SELECT COUNT(*) as c FROM constitution_articles').get().c;

if (articleCount === 0) {
  const insert = db.prepare(`INSERT INTO constitution_articles (part, article_number, title, summary, tags) VALUES (?, ?, ?, ?, ?)`);

  const articles = [
    // Preamble
    ['Preamble', 'Preamble', 'The Preamble', 'Declares India a Sovereign, Socialist, Secular, Democratic Republic securing Justice, Liberty, Equality and Fraternity to all citizens.', 'preamble,basic structure'],

    // Part III - Fundamental Rights
    ['Part III', 'Art. 12', 'Definition of "State"', 'Defines "State" to include the Government and Parliament of India, State governments and legislatures, and all local or other authorities, for the purpose of Fundamental Rights.', 'fundamental rights,state'],
    ['Part III', 'Art. 13', 'Laws inconsistent with Fundamental Rights', 'Any law inconsistent with the Fundamental Rights is void to the extent of the inconsistency; this includes pre-constitution and post-constitution laws.', 'fundamental rights,judicial review'],
    ['Part III', 'Art. 14', 'Right to Equality', 'Guarantees equality before the law and equal protection of the laws to all persons within the territory of India.', 'equality,fundamental rights'],
    ['Part III', 'Art. 15', 'Prohibition of Discrimination', 'Prohibits discrimination by the State against any citizen on grounds of religion, race, caste, sex, or place of birth; permits special provisions for women, children, and backward classes.', 'equality,discrimination,reservation'],
    ['Part III', 'Art. 16', 'Equality of Opportunity in Public Employment', 'Guarantees equality of opportunity in matters of public employment and prohibits discrimination on the listed grounds, while allowing reservations for backward classes.', 'employment,reservation'],
    ['Part III', 'Art. 17', 'Abolition of Untouchability', 'Abolishes "untouchability" and forbids its practice in any form; enforcement of any disability arising from it is a punishable offence.', 'untouchability,social justice'],
    ['Part III', 'Art. 18', 'Abolition of Titles', 'Prohibits the State from conferring titles (other than military or academic distinctions) and restricts citizens from accepting titles from foreign states.', 'titles,equality'],
    ['Part III', 'Art. 19', 'Protection of Six Freedoms', 'Guarantees freedom of speech and expression, assembly, association, movement, residence, and profession/occupation, subject to reasonable restrictions.', 'freedom of speech,expression,assembly'],
    ['Part III', 'Art. 20', 'Protection in Respect of Conviction for Offences', 'Protects against ex-post-facto laws, double jeopardy, and self-incrimination.', 'criminal law,double jeopardy'],
    ['Part III', 'Art. 21', 'Protection of Life and Personal Liberty', 'No person shall be deprived of life or personal liberty except according to procedure established by law; judicially expanded to include the right to privacy, dignity, livelihood, and more.', 'life,liberty,privacy'],
    ['Part III', 'Art. 21A', 'Right to Education', 'Guarantees free and compulsory education to all children aged 6 to 14 years, as determined by the State.', 'education,children'],
    ['Part III', 'Art. 22', 'Protection Against Arrest and Detention', 'Provides safeguards against arbitrary arrest and detention, including the right to be informed of grounds of arrest, consult a lawyer, and be produced before a magistrate within 24 hours; separate provisions apply to preventive detention.', 'arrest,detention,criminal procedure'],
    ['Part III', 'Art. 23', 'Prohibition of Traffic in Human Beings and Forced Labour', 'Prohibits trafficking in human beings, begar (forced labour without payment), and similar forms of forced labour.', 'human trafficking,forced labour'],
    ['Part III', 'Art. 24', 'Prohibition of Child Labour', 'Prohibits employment of children below 14 years in factories, mines, or other hazardous work.', 'child labour,children'],
    ['Part III', 'Art. 25', 'Freedom of Conscience and Religion', 'Guarantees freedom of conscience and the right to freely profess, practise, and propagate religion, subject to public order, morality, and health.', 'religion,secularism'],
    ['Part III', 'Art. 26', 'Freedom to Manage Religious Affairs', 'Grants every religious denomination the right to establish institutions, manage its own affairs in matters of religion, and own and administer property.', 'religion,religious institutions'],
    ['Part III', 'Art. 27', 'Freedom from Taxation for Promotion of Religion', 'No person can be compelled to pay taxes for the promotion of any particular religion or religious denomination.', 'religion,taxation'],
    ['Part III', 'Art. 28', 'Freedom from Religious Instruction in Certain Institutions', 'Prohibits religious instruction in wholly State-funded educational institutions, with exceptions for institutions established under trusts requiring such instruction.', 'religion,education'],
    ['Part III', 'Art. 29', 'Protection of Interests of Minorities', 'Protects the right of any section of citizens with a distinct language, script, or culture to conserve it, and prohibits denial of admission to educational institutions on grounds of religion, race, caste, or language.', 'minorities,culture,language'],
    ['Part III', 'Art. 30', 'Right of Minorities to Establish Educational Institutions', 'Grants religious and linguistic minorities the right to establish and administer educational institutions of their choice.', 'minorities,education'],
    ['Part III', 'Art. 32', 'Right to Constitutional Remedies', 'Guarantees the right to move the Supreme Court directly for enforcement of Fundamental Rights, including through writs such as habeas corpus, mandamus, prohibition, quo warranto, and certiorari. Called the "heart and soul" of the Constitution by Dr. B. R. Ambedkar.', 'writs,supreme court,remedies'],

    // Part IV - Directive Principles of State Policy
    ['Part IV', 'Art. 36', 'Definition (DPSP)', 'Defines "State" for the purposes of Part IV, the same as under Article 12.', 'dpsp,definition'],
    ['Part IV', 'Art. 37', 'Application of Directive Principles', 'States that the Directive Principles are not enforceable in any court but are fundamental in the governance of the country and it is the duty of the State to apply them in making laws.', 'dpsp,governance'],
    ['Part IV', 'Art. 38', 'State to Secure a Social Order for Welfare', 'Directs the State to promote the welfare of the people by securing a social order based on justice—social, economic, and political—and to minimise inequalities.', 'welfare,social justice'],
    ['Part IV', 'Art. 39', 'Certain Principles of Policy', 'Directs the State to ensure adequate livelihood, equitable distribution of resources, equal pay for equal work, and protection of workers and children from exploitation.', 'equal pay,resources,labour'],
    ['Part IV', 'Art. 39A', 'Equal Justice and Free Legal Aid', 'Directs the State to ensure equal justice and provide free legal aid so that opportunities for justice are not denied due to economic or other disabilities.', 'legal aid,justice'],
    ['Part IV', 'Art. 40', 'Organisation of Village Panchayats', 'Directs the State to organise village panchayats and endow them with powers for self-government.', 'panchayat,local government'],
    ['Part IV', 'Art. 41', 'Right to Work, Education, and Public Assistance', 'Directs the State to secure the right to work, education, and public assistance in cases of unemployment, old age, sickness, and disablement, within economic capacity.', 'employment,social security'],
    ['Part IV', 'Art. 42', 'Just and Humane Conditions of Work and Maternity Relief', 'Directs the State to make provision for just and humane conditions of work and for maternity relief.', 'labour,maternity'],
    ['Part IV', 'Art. 43', 'Living Wage for Workers', 'Directs the State to endeavour to secure a living wage and decent standard of life for workers.', 'wages,labour'],
    ['Part IV', 'Art. 44', 'Uniform Civil Code', 'Directs the State to endeavour to secure a Uniform Civil Code for all citizens throughout India.', 'ucc,personal law'],
    ['Part IV', 'Art. 45', 'Early Childhood Care and Education', 'Directs the State to endeavour to provide early childhood care and education for children below the age of six.', 'education,children'],
    ['Part IV', 'Art. 46', 'Promotion of Educational and Economic Interests of SC/ST and Weaker Sections', 'Directs the State to promote the educational and economic interests of Scheduled Castes, Scheduled Tribes, and other weaker sections, and protect them from social injustice.', 'sc/st,social justice'],
    ['Part IV', 'Art. 47', 'Duty to Raise Nutrition, Standard of Living, and Public Health', 'Directs the State to raise the level of nutrition and standard of living, and to improve public health, including prohibition of intoxicating drinks and drugs injurious to health.', 'public health,nutrition'],
    ['Part IV', 'Art. 48', 'Organisation of Agriculture and Animal Husbandry', 'Directs the State to organise agriculture and animal husbandry on modern and scientific lines and to prohibit slaughter of cows, calves, and other milch/draught cattle.', 'agriculture,cattle'],
    ['Part IV', 'Art. 48A', 'Protection of Environment', 'Directs the State to protect and improve the environment and to safeguard forests and wildlife.', 'environment,wildlife'],
    ['Part IV', 'Art. 49', 'Protection of Monuments and Places of National Importance', 'Directs the State to protect monuments, places, and objects of artistic or historic interest.', 'heritage,monuments'],
    ['Part IV', 'Art. 50', 'Separation of Judiciary from Executive', 'Directs the State to take steps to separate the judiciary from the executive in public services.', 'judiciary,separation of powers'],
    ['Part IV', 'Art. 51', 'Promotion of International Peace and Security', 'Directs the State to promote international peace and security, maintain just relations between nations, and encourage settlement of disputes by arbitration.', 'international law,peace'],

    // Part IVA - Fundamental Duties
    ['Part IVA', 'Art. 51A', 'Fundamental Duties', 'Lists 11 duties of every citizen, including abiding by the Constitution, respecting the National Flag and Anthem, upholding sovereignty and integrity of India, promoting harmony, protecting the environment and public property, and striving for excellence.', 'fundamental duties,citizens'],
  ];

  const insertMany = db.transaction((rows) => {
    for (const row of rows) insert.run(...row);
  });
  insertMany(articles);
  console.log(`Seeded ${articles.length} constitution articles.`);
}

const newsCount = db.prepare('SELECT COUNT(*) as c FROM news').get().c;
if (newsCount === 0) {
  const insertNews = db.prepare(`INSERT INTO news (title, content, category, source_name, source_url, published_date) VALUES (?, ?, ?, ?, ?, ?)`);
  insertNews.run(
    'Welcome to the Legal Portal',
    'This is a sample news entry. Replace or add real legal news items using the admin API (POST /api/news) or by editing the database directly.',
    'General',
    'Legal Portal Team',
    '',
    new Date().toISOString().slice(0, 10)
  );
  console.log('Seeded sample news item.');
}

const faqCount = db.prepare('SELECT COUNT(*) as c FROM faqs').get().c;
if (faqCount === 0) {
  const insertFaq = db.prepare(`INSERT INTO faqs (question, answer, category) VALUES (?, ?, ?)`);
  const faqs = [
    ['What is a Fundamental Right?', 'Fundamental Rights are basic human rights guaranteed to all citizens by Part III of the Indian Constitution (Articles 12-32). They are justiciable, meaning citizens can approach courts directly if these rights are violated.', 'Constitution'],
    ['What is the difference between Fundamental Rights and Directive Principles?', 'Fundamental Rights (Part III) are legally enforceable in court, while Directive Principles of State Policy (Part IV) are guidelines for governance that are not enforceable but are considered fundamental in law-making.', 'Constitution'],
    ['How do I file an FIR?', 'An FIR (First Information Report) can be filed at the police station having jurisdiction over the area where the offence occurred, or at any police station under the "Zero FIR" provision, which is then transferred to the appropriate station.', 'Criminal Law'],
    ['What is anticipatory bail?', 'Anticipatory bail is a legal provision under Section 438 of the CrPC (now Section 482 of BNSS) that allows a person to seek bail in anticipation of arrest on accusation of having committed a non-bailable offence.', 'Criminal Law'],
    ['What is the procedure for filing a PIL?', 'A Public Interest Litigation (PIL) can be filed in the Supreme Court under Article 32 or in a High Court under Article 226, by any public-spirited citizen, on matters of public interest such as environmental issues or violation of fundamental rights of a group.', 'Constitutional Law'],
    ['What is the minimum age for marriage in India?', 'The legal minimum age for marriage is 21 years for men and 18 years for women, as per the Prohibition of Child Marriage Act, 2006.', 'Family Law'],
    ['Can a citizen be denied the Right to Education?', 'No. Article 21A guarantees free and compulsory education to all children between the ages of 6 and 14 as a Fundamental Right.', 'Constitution'],
    ['What is a writ of Habeas Corpus?', 'Habeas Corpus is a writ issued by a court to produce a person who has been detained, to determine whether the detention is lawful. It is used to protect personal liberty under Article 32 or 226.', 'Constitutional Law'],
    ['Is the Right to Privacy a Fundamental Right in India?', 'Yes. In the 2017 judgment K.S. Puttaswamy v. Union of India, the Supreme Court held that the Right to Privacy is a Fundamental Right protected under Article 21.', 'Constitution'],
    ['What legal aid is available to those who cannot afford a lawyer?', 'Free legal aid is available under the Legal Services Authorities Act, 1987, through National, State, and District Legal Services Authorities, in line with Article 39A of the Constitution.', 'Legal Aid']
  ];
  const insertManyFaq = db.transaction((rows) => {
    for (const row of rows) insertFaq.run(...row);
  });
  insertManyFaq(faqs);
  console.log(`Seeded ${faqs.length} FAQs.`);
}

module.exports = db;
